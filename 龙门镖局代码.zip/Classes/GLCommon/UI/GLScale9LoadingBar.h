#ifndef __GLSCALELOADINGBAER_H__
#define  __GLSCALELOADINGBAER_H__

#include "cocos2d.h"
USING_NS_CC;

namespace glui {
	class GLScale9LoadingBar : public ui::LoadingBar
}

#endif
