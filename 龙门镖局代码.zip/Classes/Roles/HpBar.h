#ifndef __HP_BAR_H__
#define __HP_BAR_H__

#include "cocos2d.h"

USING_NS_CC;


class HpBar : public Node
{
public:

private:
	ui::LoadingBar _
};

#endif
