#include "CrushMsg.h"

const string CrushMsg::TOUCH_BEGAN = "touch_begin";
const string CrushMsg::TOUCH_MOVED = "touch_moved";
const string CrushMsg::TOUCH_ENDED = "touch_ended";
const string CrushMsg::TOUCH_CANCELLED = "touch_cancelled";