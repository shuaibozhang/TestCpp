#include "EleWeak.h"

EleWeak * EleWeak::create(int id)
{
	return nullptr;
}
