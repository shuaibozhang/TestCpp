//
//  ensDefine.cpp
//  HelloCpp
//
//  Created by yang chao (wantnon) on 14-6-14.
//
//

#include "ensDefine.h"
namespace_ens_begin

namespace_ens_end