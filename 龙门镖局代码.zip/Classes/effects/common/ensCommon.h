//
//  ensCommon.h
//  HelloCpp
//
//  Created by yang chao (wantnon) on 14-6-14.
//
//

#ifndef HelloCpp_ensCommon_h
#define HelloCpp_ensCommon_h

#include "ensDefine.h"
#include "ensFunc.h"
#include "ensMath.h"
#include "ensSimpleClasses.h"
#include "ensIndexVBO.h"
#include "ensGLProgramWithUnifos.h"
#include "ensMesh.h"
#endif
